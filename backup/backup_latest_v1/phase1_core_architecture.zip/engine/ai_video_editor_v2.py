from pathlib import Path
import json
from engine.brains import NicheBrain, StoryBrain, VisualBrain, EditingBrain, AudioBrain, CaptionBrain, EffectsBrain, MemoryBrain, RenderBrain
from engine.planner.timeline_planner import build_phase1_timeline
VERSION="AI_VIDEO_EDITOR_V2_PHASE_1_CORE_ARCHITECTURE"
class AIVideoEditorV2:
    def __init__(self):
        self.brains=[NicheBrain(),StoryBrain(),VisualBrain(),EditingBrain(),AudioBrain(),CaptionBrain(),EffectsBrain(),MemoryBrain(),RenderBrain()]
    def plan_only(self, context):
        results={}; warnings=[]
        for brain in self.brains:
            r=brain.run(context)
            results[r.name]={"ok":r.ok,"data":r.data,"warnings":r.warnings,"seconds":r.seconds}
            warnings.extend(r.warnings)
        return {"version":VERSION,"phase":1,"ok":all(x["ok"] for x in results.values()),"render_executed":False,"final_video_created":False,"brains":results,"timeline":build_phase1_timeline(context,results),"warnings":warnings}
def save_phase1_report(report,path="outputs/phase1_core_report.json"):
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(report,indent=2),encoding="utf-8"); return str(p)
