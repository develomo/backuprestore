def build_phase1_timeline(context, brain_outputs):
    clips=context.get("clips") or []
    duration=float(context.get("voice_duration") or 0.0)
    return {"timeline_version":"phase1_plan_only","clip_count":len(clips),"voice_duration":duration,"average_clip_duration":round(duration/len(clips),2) if clips else 0,"render_test_allowed":False,"final_video_render":False,"brain_outputs_attached":sorted(brain_outputs.keys())}
