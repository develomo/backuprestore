from .base import BaseBrain
class EditingBrain(BaseBrain):
    name="editing_brain"
    def process(self, context):
        clips=context.get("clips") or []; dur=float(context.get("voice_duration") or 0.0)
        avg=round(dur/len(clips),2) if clips else 0
        return {"dynamic_pacing":True,"average_clip_duration":avg,"duration_range":[4,12],"ken_burns":True,"transition_variation":True,"pattern_interrupts":True}
