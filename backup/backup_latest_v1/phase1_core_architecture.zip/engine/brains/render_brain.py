from .base import BaseBrain
class RenderBrain(BaseBrain):
    name="render_brain"
    def process(self, context):
        mode=str(context.get("mode") or "LONG").upper()
        return {"renderer":"ffmpeg_batch","mode":mode,"quality":context.get("quality") or ("480p" if mode=="LONG" else "1080p"),"fps":24 if mode=="LONG" else 30,"hidden_upscale":False,"final_video_render_in_phase1":False}
