from .base import BaseBrain
import re
class StoryBrain(BaseBrain):
    name="story_brain"
    def process(self, context):
        text=str(context.get("transcript_text") or "")
        sentences=[s.strip() for s in re.split(r"(?<=[.!?])\s+",text) if s.strip()]
        cs=max(1,len(sentences)//6) if sentences else 1
        chapters=[{"chapter_index":i//cs+1,"start_sentence":i,"end_sentence":min(len(sentences)-1,i+cs-1)} for i in range(0,len(sentences),cs)] if sentences else []
        return {"has_transcript":bool(text),"sentence_count":len(sentences),"sentences":sentences[:20],"chapters":chapters}
