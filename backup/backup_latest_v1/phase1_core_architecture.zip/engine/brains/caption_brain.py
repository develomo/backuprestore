from .base import BaseBrain
class CaptionBrain(BaseBrain):
    name="caption_brain"
    def process(self, context):
        return {"enabled":bool(context.get("add_captions")),"mode":context.get("caption_mode") or "phrase","style_id":context.get("style_id"),"real_voice_words_only":True,"multilingual":True,"fake_preview_words_blocked":True}
