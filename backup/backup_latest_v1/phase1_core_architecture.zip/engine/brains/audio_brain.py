from .base import BaseBrain
class AudioBrain(BaseBrain):
    name="audio_brain"
    def process(self, context):
        niche=str(context.get("niche") or "default").lower()
        return {"target_lufs":-16 if niche=="luxury" else -14,"true_peak":-1,"eq":{"highpass_hz":90,"presence_boost_db":2},"compression":{"ratio":"3:1","threshold_db":-20},"ducking":True,"fade":{"in":0.6,"out":0.8}}
