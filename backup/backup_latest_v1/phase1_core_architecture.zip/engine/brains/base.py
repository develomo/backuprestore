from dataclasses import dataclass, field
from typing import Any, Dict, List
import time
@dataclass
class BrainResult:
    name:str; ok:bool=True; data:Dict[str,Any]=field(default_factory=dict); warnings:List[str]=field(default_factory=list); seconds:float=0.0
class BaseBrain:
    name="base"
    def run(self, context):
        st=time.time()
        try: return BrainResult(self.name, True, self.process(context), [], round(time.time()-st,4))
        except Exception as e: return BrainResult(self.name, False, {}, [str(e)], round(time.time()-st,4))
    def process(self, context): return {}
