from .base import BaseBrain
class MemoryBrain(BaseBrain):
    name="memory_brain"
    def process(self, context):
        count=len(context.get("clips") or [])
        return {"render_strategy":"batch","batch_size":8 if count>40 else 12,"avoid_full_moviepy_timeline":True,"cleanup_after_each_batch":True,"delete_temp_after_final":True}
