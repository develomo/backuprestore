from .base import BaseBrain
class NicheBrain(BaseBrain):
    name="niche_brain"
    PROFILES={"luxury":{"pacing":"slow_elegant","motion":"smooth_push","transition":"soft_dissolve","color":"cool_luxury","audio":"ambient_cinematic"},"finance":{"pacing":"clean_corporate","motion":"controlled_zoom","transition":"clean_cut","color":"blue_corporate","audio":"subtle_corporate"},"ai":{"pacing":"modern_dynamic","motion":"digital_push","transition":"light_glitch","color":"neon_cyber","audio":"synth_ambient"},"islamic":{"pacing":"respectful_calm","motion":"gentle_push","transition":"soft_fade","color":"warm_soft","audio":"very_soft_ambient"},"home_design":{"pacing":"calm_aesthetic","motion":"smooth_pan","transition":"soft_dissolve","color":"warm_clean","audio":"cozy_ambient"},"default":{"pacing":"balanced_documentary","motion":"slow_push","transition":"soft_cut","color":"cinematic_clean","audio":"documentary_ambient"}}
    def process(self, context):
        niche=str(context.get("niche") or "default").lower().strip()
        return {"niche":niche,"profile":self.PROFILES.get(niche,self.PROFILES["default"])}
