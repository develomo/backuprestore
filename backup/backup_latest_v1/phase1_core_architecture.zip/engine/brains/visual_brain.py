from .base import BaseBrain
class VisualBrain(BaseBrain):
    name="visual_brain"
    def process(self, context):
        mode=str(context.get("mode") or "LONG").upper()
        target={"width":1080,"height":1920,"aspect":"9:16"} if mode=="SHORT" else {"width":854,"height":480,"aspect":"16:9"}
        return {"target":target,"clip_count":len(context.get("clips") or []),"force_same_aspect_ratio":True,"black_bar_detection_required":True,"no_stretch":True}
