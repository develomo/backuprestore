from .base import BaseBrain
class EffectsBrain(BaseBrain):
    name="effects_brain"
    def process(self, context):
        respectful=str(context.get("niche") or "").lower()=="islamic"
        return {"pattern_interrupts":{"enabled":True,"every_seconds":150},"motion_blur":not respectful,"light_leak":not respectful,"film_grain":"very_subtle","respectful_mode":respectful}
