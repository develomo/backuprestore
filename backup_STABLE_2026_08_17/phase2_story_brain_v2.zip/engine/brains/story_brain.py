from __future__ import annotations

from typing import Any, Dict, List, Tuple
from .base import BaseBrain
import re
import math


class StoryBrain(BaseBrain):
    """Story Brain V2

    Phase 2 purpose:
    - Analyze transcript/sentences only.
    - Do not render video.
    - Create story intelligence that future Editing/Visual/Audio brains will use.

    Output:
    - sentence analysis
    - emotion
    - energy
    - importance
    - visual intent
    - camera suggestion
    - transition suggestion
    - music mood
    - chapters
    - pattern interrupt points
    """

    name = "story_brain"

    EMOTION_KEYWORDS = {
        "luxury": [
            "luxury", "mansion", "villa", "palace", "premium", "expensive", "wealth",
            "private", "exclusive", "elegant", "gold", "marble", "pool", "suite",
            "designer", "estate", "penthouse", "resort"
        ],
        "calm": [
            "calm", "peace", "quiet", "soft", "gentle", "warm", "cozy", "comfort",
            "relax", "serene", "slow", "beautiful", "silent", "still"
        ],
        "suspense": [
            "hidden", "secret", "mystery", "suddenly", "unknown", "beneath", "dark",
            "danger", "warning", "strange", "fear", "fearless", "shadow", "locked",
            "revealed", "unseen"
        ],
        "curiosity": [
            "discovered", "scientists", "why", "how", "what", "question", "reveals",
            "research", "future", "technology", "ai", "robot", "machine", "data",
            "experiment"
        ],
        "finance": [
            "money", "market", "profit", "loss", "stock", "business", "investment",
            "investor", "price", "bank", "economy", "dollar", "million", "billion",
            "wealth", "cash"
        ],
        "spiritual": [
            "faith", "allah", "islam", "prayer", "spiritual", "soul", "mercy",
            "peace", "quran", "mosque", "blessing", "patience", "guidance"
        ],
        "dramatic": [
            "never", "forever", "changed", "destroyed", "created", "first time",
            "last time", "impossible", "unbelievable", "shocking", "powerful",
            "massive", "huge"
        ],
    }

    VISUAL_KEYWORDS = {
        "wide_establishing": [
            "mountain", "valley", "city", "skyline", "landscape", "ocean", "desert",
            "forest", "view", "outside", "drone", "aerial", "estate", "mansion",
            "villa", "palace"
        ],
        "interior": [
            "room", "hall", "interior", "kitchen", "bedroom", "bathroom", "fireplace",
            "sofa", "living", "stairs", "corridor", "lobby", "marble", "wood"
        ],
        "closeup": [
            "detail", "gold", "watch", "hand", "face", "eyes", "door", "key",
            "screen", "device", "object", "texture", "glass", "fabric"
        ],
        "data_graphics": [
            "money", "market", "stock", "graph", "chart", "number", "price",
            "profit", "loss", "economy", "percentage", "growth"
        ],
        "tech_visual": [
            "ai", "robot", "computer", "digital", "future", "network", "chip",
            "machine", "data", "algorithm", "automation", "software"
        ],
        "spiritual_visual": [
            "mosque", "prayer", "quran", "islam", "faith", "spiritual", "soul",
            "mercy", "patience", "guidance"
        ],
    }

    HOOK_WORDS = [
        "imagine", "what if", "you won't believe", "nobody", "secret", "hidden",
        "first time", "last time", "most", "biggest", "dangerous", "powerful",
        "shocking", "changed forever", "never"
    ]

    CTA_WORDS = [
        "subscribe", "follow", "like", "comment", "share", "watch next", "channel"
    ]

    REVEAL_WORDS = [
        "revealed", "turns out", "but then", "however", "finally", "truth",
        "secret", "hidden", "discovered"
    ]

    def _sentences(self, text: str) -> List[str]:
        text = str(text or "").replace("\n", " ").strip()
        if not text:
            return []
        # Split by punctuation while keeping long TTS scripts readable.
        raw = re.split(r"(?<=[.!?])\s+|(?<=।)\s+", text)
        sentences = []
        for part in raw:
            part = part.strip()
            if len(part) < 2:
                continue
            # If sentence is extremely long, split by commas every few clauses.
            if len(part.split()) > 38:
                clauses = [x.strip() for x in re.split(r",|;|—|-", part) if x.strip()]
                if len(clauses) > 1:
                    sentences.extend(clauses)
                else:
                    sentences.append(part)
            else:
                sentences.append(part)
        return sentences

    def _score_keywords(self, sentence: str, groups: Dict[str, List[str]]) -> Dict[str, int]:
        s = sentence.lower()
        scores: Dict[str, int] = {}
        for group, words in groups.items():
            score = 0
            for w in words:
                if w in s:
                    score += 1
            scores[group] = score
        return scores

    def _top_label(self, scores: Dict[str, int], default: str) -> str:
        if not scores:
            return default
        best = max(scores.items(), key=lambda x: x[1])
        return best[0] if best[1] > 0 else default

    def _sentence_energy(self, sentence: str, emotion: str, index: int, total: int) -> str:
        s = sentence.lower()
        marks = sentence.count("!") + sentence.count("?")
        word_count = len(sentence.split())

        score = 0
        if marks:
            score += 2
        if emotion in {"suspense", "dramatic", "curiosity"}:
            score += 2
        if any(w in s for w in ["suddenly", "never", "secret", "shocking", "danger", "massive"]):
            score += 2
        if word_count <= 7:
            score += 1
        if index == 0:
            score += 2
        if total and index > total * 0.85:
            score += 1

        if score >= 5:
            return "high"
        if score >= 3:
            return "medium_high"
        if score >= 1:
            return "medium"
        return "low"

    def _importance(self, sentence: str, emotion: str, energy: str, index: int, total: int) -> int:
        s = sentence.lower()
        score = 45

        if index == 0:
            score += 25
        if total and index >= total - 2:
            score += 10
        if energy == "high":
            score += 22
        elif energy == "medium_high":
            score += 14
        elif energy == "medium":
            score += 7

        if emotion in {"luxury", "suspense", "dramatic", "curiosity"}:
            score += 8
        if any(w in s for w in self.HOOK_WORDS):
            score += 16
        if any(w in s for w in self.REVEAL_WORDS):
            score += 12
        if any(w in s for w in self.CTA_WORDS):
            score += 6

        word_count = len(sentence.split())
        if 8 <= word_count <= 24:
            score += 5
        elif word_count > 35:
            score -= 8

        return max(0, min(100, score))

    def _visual_intent(self, sentence: str, niche: str) -> str:
        scores = self._score_keywords(sentence, self.VISUAL_KEYWORDS)
        label = self._top_label(scores, "wide_establishing")

        if niche == "finance" and label == "wide_establishing":
            return "data_graphics"
        if niche == "ai" and label == "wide_establishing":
            return "tech_visual"
        if niche == "islamic" and label == "wide_establishing":
            return "spiritual_visual"
        return label

    def _camera(self, emotion: str, energy: str, visual: str, index: int) -> str:
        if visual == "closeup":
            return "slow_push_in"
        if visual == "wide_establishing":
            return "slow_zoom_out" if index % 2 else "slow_push_in"
        if visual in {"data_graphics", "tech_visual"}:
            return "controlled_push"
        if emotion == "suspense":
            return "deep_push_in"
        if energy in {"high", "medium_high"}:
            return "push_in_with_micro_pan"
        return "gentle_pan"

    def _transition(self, emotion: str, energy: str, niche: str, index: int) -> str:
        if niche == "islamic":
            return "soft_fade"
        if energy == "high" and emotion in {"suspense", "dramatic"}:
            return "flash_or_light_cut"
        if index % 6 == 0:
            return "creative_soft_transition"
        if emotion in {"luxury", "calm"}:
            return "soft_dissolve"
        return "clean_cut"

    def _music_mood(self, emotion: str, niche: str) -> str:
        if niche == "luxury" or emotion == "luxury":
            return "luxury_ambient"
        if niche == "finance" or emotion == "finance":
            return "corporate_minimal"
        if niche == "ai" or emotion == "curiosity":
            return "synth_documentary"
        if niche == "islamic" or emotion == "spiritual":
            return "soft_respectful_ambient"
        if emotion == "suspense":
            return "dark_subtle_tension"
        return "documentary_ambient"

    def _sentence_type(self, sentence: str, index: int, total: int) -> str:
        s = sentence.lower()
        if index == 0 or any(w in s for w in self.HOOK_WORDS):
            return "hook"
        if any(w in s for w in self.CTA_WORDS):
            return "cta"
        if any(w in s for w in self.REVEAL_WORDS):
            return "reveal"
        if "?" in sentence:
            return "question"
        if total and index >= total - 2:
            return "ending"
        return "story"

    def _chapters(self, analyses: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        if not analyses:
            return []

        total = len(analyses)
        desired = min(8, max(3, math.ceil(total / 8)))
        chapter_size = max(1, math.ceil(total / desired))
        chapters = []

        for start in range(0, total, chapter_size):
            end = min(total - 1, start + chapter_size - 1)
            slice_items = analyses[start:end + 1]
            avg_importance = round(sum(x["importance"] for x in slice_items) / max(1, len(slice_items)), 2)
            dominant_emotion = self._dominant([x["emotion"] for x in slice_items], "calm")
            chapters.append({
                "chapter_index": len(chapters) + 1,
                "start_sentence": start,
                "end_sentence": end,
                "dominant_emotion": dominant_emotion,
                "average_importance": avg_importance,
                "recommended_hook": slice_items[0]["sentence"],
                "pattern_interrupt_at_start": len(chapters) > 0,
            })
        return chapters

    def _dominant(self, values: List[str], default: str) -> str:
        counts: Dict[str, int] = {}
        for v in values:
            counts[v] = counts.get(v, 0) + 1
        if not counts:
            return default
        return max(counts.items(), key=lambda x: x[1])[0]

    def _pattern_interrupts(self, analyses: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        points = []
        for item in analyses:
            if item["sentence_type"] in {"hook", "reveal", "question"} or item["importance"] >= 82:
                points.append({
                    "sentence_index": item["index"],
                    "reason": item["sentence_type"] if item["sentence_type"] != "story" else "high_importance",
                    "suggestion": "change_motion_or_transition",
                    "energy": item["energy"],
                })
        # avoid too many interrupts
        return points[:12]

    def process(self, context: Dict[str, Any]) -> Dict[str, Any]:
        niche = str(context.get("niche") or "default").lower().strip()
        transcript = str(context.get("transcript_text") or "")
        sentences = self._sentences(transcript)

        analyses: List[Dict[str, Any]] = []
        total = len(sentences)

        for index, sentence in enumerate(sentences):
            emotion_scores = self._score_keywords(sentence, self.EMOTION_KEYWORDS)
            emotion = self._top_label(emotion_scores, "calm")
            energy = self._sentence_energy(sentence, emotion, index, total)
            importance = self._importance(sentence, emotion, energy, index, total)
            visual = self._visual_intent(sentence, niche)
            sentence_type = self._sentence_type(sentence, index, total)

            analyses.append({
                "index": index,
                "sentence": sentence,
                "word_count": len(sentence.split()),
                "emotion": emotion,
                "energy": energy,
                "importance": importance,
                "visual_intent": visual,
                "camera_suggestion": self._camera(emotion, energy, visual, index),
                "transition_suggestion": self._transition(emotion, energy, niche, index),
                "music_mood": self._music_mood(emotion, niche),
                "sentence_type": sentence_type,
                "emotion_scores": emotion_scores,
            })

        chapters = self._chapters(analyses)
        interrupts = self._pattern_interrupts(analyses)

        return {
            "version": "story_brain_v2_phase2",
            "has_transcript": bool(transcript),
            "sentence_count": len(sentences),
            "niche": niche,
            "dominant_emotion": self._dominant([x["emotion"] for x in analyses], "calm"),
            "average_importance": round(sum(x["importance"] for x in analyses) / max(1, len(analyses)), 2) if analyses else 0,
            "sentences": analyses,
            "chapters": chapters,
            "pattern_interrupts": interrupts,
            "editing_handoff": {
                "use_dynamic_pacing": True,
                "use_story_based_camera": True,
                "use_story_based_transitions": True,
                "use_music_mood": True,
                "use_pattern_interrupts": True,
            },
        }
